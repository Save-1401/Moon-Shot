﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LunarOre : MonoBehaviour
{
    public int points;

    public void OnPlayerHit()
    {
        Destroy(gameObject);
    }
}
