﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public RocketShip player;
    public AsteroidManager am;

    public GameObject upgradePanel;

    public Slider hullIntegritySlider;
    public Image hullIntegritySliderImage;
    public Gradient hullIntegritySliderColor;

    public Material empty;
    public Material bought;

    public Text points;

    public Text hit;
    public Text st;
    public Text it;
    public Text smt;
    public Text fmt;
    public Text mt;

    public Image[] hullIntegrity;
    public Image[] speed;
    public Image[] inertia;
    public Image[] slowMod;
    public Image[] fastMod;
    public Image[] manuverability;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (player.isDead)
        {
            upgradePanel.SetActive(true);
        }
        points.text = "" + player.stats.points;

        SetPriceText(player.stats.levels.hullIntegrity, player.stats.pointsToUpgrade.hullIntegrity, hit);
        SetPriceText(player.stats.levels.speed, player.stats.pointsToUpgrade.speed, st);
        SetPriceText(player.stats.levels.inertia, player.stats.pointsToUpgrade.inertia, it);
        SetPriceText(player.stats.levels.slowMod, player.stats.pointsToUpgrade.slowMod, smt);
        SetPriceText(player.stats.levels.fastMod, player.stats.pointsToUpgrade.fastMod, fmt);
        SetPriceText(player.stats.levels.manuverability, player.stats.pointsToUpgrade.manuverability, mt);

        CheckLevels(player.stats.levels.hullIntegrity, hullIntegrity);
        CheckLevels(player.stats.levels.speed, speed);
        CheckLevels(player.stats.levels.inertia, inertia);
        CheckLevels(player.stats.levels.slowMod, slowMod);
        CheckLevels(player.stats.levels.fastMod, fastMod);
        CheckLevels(player.stats.levels.manuverability, manuverability);

        hullIntegritySlider.maxValue = player.stats.upgrades.hullIntegrity[player.stats.levels.hullIntegrity];
        hullIntegritySlider.value = player.stats.hullIntegrity;

        hullIntegritySliderImage.color = hullIntegritySliderColor.Evaluate(hullIntegritySlider.value / hullIntegritySlider.maxValue);
    }
    public void SetPriceText(int level, int[] pointsToUpgrade, Text t)
    {
        if (level < pointsToUpgrade.Length)
            SetPriceText("$" + pointsToUpgrade[level], t);
        else
            SetPriceText("Max", t);
    }
    public void SetPriceText(string value, Text t)
    {
        t.text = value;
    }
    public void CheckLevels(int level, Image[] levels)
    {
        for (int i = 0; i < levels.Length; i++)
        {
            if (i <= level && levels[i].material != bought)
            {
                levels[i].material = bought;
            }
            else if (i > level && levels[i].material != empty)
            {
                levels[i].material = empty;
            }
        }
    }
    public void Restart()
    {
        player.stats.hullIntegrity = player.stats.upgrades.hullIntegrity[player.stats.levels.hullIntegrity];
        player.transform.position = Vector3.zero;
        player.transform.eulerAngles = Vector3.zero;
        player.gameObject.SetActive(true);
        player.cam.parent = player.transform;
        player.currentCameraSetting = player.firstPerson;
        player.isDead = false;
        player.SetCamera(0f, 0f);
        am.StartLoop();
        Cursor.lockState = CursorLockMode.Locked;
        Time.timeScale = 1f;
        upgradePanel.SetActive(false);
    }
}
