﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidManager : MonoBehaviour
{
    public float distance;
    public GameObject asteroidSpawner;
    [SerializeField, HideInInspector]
    List<GameObject> asteroidSpawners = new List<GameObject>();
    public float maxSpawners;
    public float distanceUntillNextSpawn;
    Vector3 oldPos = Vector3.zero;
    public Transform player;
    // Start is called before the first frame update
    void Start()
    {
        StartLoop();
    }

    public void StartLoop()
    {
        for (float i = distanceUntillNextSpawn; i <= distance; i += distanceUntillNextSpawn)
        {
            transform.position = player.position + Vector3.forward * i;
            CreateNewAsteroidSpawner();
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (player != null)
            KeepDistance();
        MonitorMovement();
    }
    public void KeepDistance()
    {
        transform.position = Vector3.forward * (distance + player.position.z);
    }
    public void MonitorMovement()
    {
        if (Vector3.Distance(oldPos, transform.position) >= distanceUntillNextSpawn)
        {
            CreateNewAsteroidSpawner();
            oldPos = transform.position;
        }
    }
    public void CreateNewAsteroidSpawner()
    {
        asteroidSpawners.Insert(0, Instantiate(asteroidSpawner, transform.position, transform.rotation));
        asteroidSpawners[0].GetComponent<AsteroidSpawner>().player = player;
        if (asteroidSpawners.Count > maxSpawners)
        {
            Destroy(asteroidSpawners[asteroidSpawners.Count - 1]);
            asteroidSpawners.RemoveAt(asteroidSpawners.Count - 1);
        }
    }
}
