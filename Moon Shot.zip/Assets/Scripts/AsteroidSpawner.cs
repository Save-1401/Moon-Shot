﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Dimensionality { TwoDimensional, ThreeDimensional }
public class AsteroidSpawner : MonoBehaviour
{
    public Dimensionality dimensionality;
    [Space]
    public WeightedGameObject[] asteroidPrefabs;
    [Space]
    [Space]
    public Transform player;
    public int asteroidsPerFrame;
    public float maxPlayerDistance;
    public Vector2 asteroidSpawnRadiusRange;
    public Vector2 asteroidOffsetRange;
    public Vector2Int asteroidCountRange;
    public Vector2 asteroidSizeRange;
    public Vector2 asteroidVelocityRange;
    public Vector2 asteroidHealthRange;
    public int asteroidCount;
    int currentAsteroid = 0;
    public List<GameObject> asteroids;
    public List<GameObject> asteroidsDeactivated;
    public float frameRate;
    // Start is called before the first frame update
    void Start()
    {
        asteroidCount = Random.Range(asteroidCountRange.x, asteroidCountRange.y);
    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < asteroidsPerFrame; i++)
            SpawnAsteroids();
        CheckDeactivatedAstroids();
        frameRate = 1f / Time.deltaTime;
    }
    #region asteroid creation
    public void SpawnAsteroids()
    {
        if (currentAsteroid < asteroidCount)
        {
            asteroids.Add(CreateAsteroid());
            currentAsteroid++;
        }
    }
    public GameObject CreateAsteroid()
    {
        GameObject asteroid = Instantiate(CalculateAsteroid(), transform);
        asteroid.transform.position = CalculateRandomPoint();
        asteroid.transform.localRotation = CalculateRandomRotation();
        asteroid.transform.localScale = CalculateRandomScale();
        asteroid.GetComponent<Asteroid>().Set(this);
        return asteroid;
    }
    public GameObject CalculateAsteroid()
    {
        List<GameObject> asteroids = new List<GameObject>();
        foreach (WeightedGameObject wgo in asteroidPrefabs)
        {
            for (int i = 0; i < wgo.weight; i++)
            {
                asteroids.Add(wgo.go);
            }
        }
        return asteroids[Random.Range(0, asteroids.Count)];
    }
    public Vector3 CalculateRandomPoint()
    {
        if (dimensionality == Dimensionality.TwoDimensional)
        {
            Vector2 point = CalculateRandomPoint2D();
            return transform.position + transform.right.normalized * point.x + transform.up.normalized * point.y + transform.forward * Random.Range(asteroidOffsetRange.x, asteroidOffsetRange.y);
        }
        else if (dimensionality == Dimensionality.ThreeDimensional)
        {
            return CalculateRandomPoint3D();
        }
        return transform.position;
    }
    public Vector3 CalculateRandomPoint3D()
    {
        Vector3 point = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;

        point *= Mathf.Sqrt(Random.Range(asteroidSpawnRadiusRange.x * asteroidSpawnRadiusRange.x, asteroidSpawnRadiusRange.y * asteroidSpawnRadiusRange.y));

        return point;
    }
    public Vector2 CalculateRandomPoint2D()
    {
        Vector2 point = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;

        point *= Mathf.Sqrt(Random.Range(asteroidSpawnRadiusRange.x * asteroidSpawnRadiusRange.x, asteroidSpawnRadiusRange.y * asteroidSpawnRadiusRange.y));

        return point;
    }
    public Quaternion CalculateRandomRotation()
    {
        return Quaternion.Euler(Random.Range(0f, 360f), Random.Range(0f, 360f), Random.Range(0f, 360f));
    }
    public Vector3 CalculateRandomScale()
    {
        float scale = Random.Range(asteroidSizeRange.x, asteroidSizeRange.y);
        return new Vector3(scale, scale, scale);
    }
    public Vector3 CalculateRandomVelocity()
    {
        Vector3 point = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;

        float mod = Random.Range(Mathf.Sqrt(asteroidVelocityRange.x), Mathf.Sqrt(asteroidVelocityRange.y));
        point *= mod * mod;

        return point;
    }
    public float GenerateRandomHealth()
    {
        return Random.Range(asteroidHealthRange.x, asteroidHealthRange.y);
    }
    #endregion
    public void CheckDeactivatedAstroids()
    {
        if (asteroidsDeactivated.Count > 0)
        {
            for (int i = 0; i < asteroidsDeactivated.Count; i++)
            {
                if (Vector3.Distance(asteroidsDeactivated[i].transform.position, player.position) <= maxPlayerDistance)
                {
                    asteroidsDeactivated[i].gameObject.SetActive(true);
                    asteroidsDeactivated.RemoveAt(i);
                    i--;
                }
            }
        }
    }
}
