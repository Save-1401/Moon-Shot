﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class CameraSetting
{
    public string name;
    public float mouseSensitivity = 100f;
    public Vector3 position;
    public Vector3 rotation;
    public bool invertX;
    public Axis mouseX;
    public bool invertY;
    public Axis mouseY;
    public bool doOverrideSpeed = false;
    [ConditionalProperty("doOverrideSpeed")]
    public float overrideSpeed;
    public bool doOverrideSlowMod = false;
    [ConditionalProperty("doOverrideSlowMod")]
    public float overrideSlowMod;
    public bool doOverrideFastMod = false;
    [ConditionalProperty("doOverrideFastMod")]
    public float overrideFastMod;
    public bool doCameraLag = false;
    [ConditionalProperty("doCameraLag")]
    public float cameraLag;
    [ConditionalProperty("doCameraLag")]
    public float cameraLagMod;

    RocketShip player;
    // Start is called before the first frame update
    public void Start(RocketShip player)
    {
        this.player = player;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetCamera(Transform player, Transform cam, float xLag, float yLag)
    {
        xLag *= cameraLagMod;
        yLag *= cameraLagMod;
        if (doCameraLag)
        {
            cam.localPosition = Vector3.Lerp(cam.localPosition, position + (cam.transform.right * xLag) + (cam.transform.up * yLag), cameraLag * Time.deltaTime);
            cam.localEulerAngles = rotation;
        }
        else
        {
            cam.localPosition = position;
            cam.localEulerAngles = rotation;
        }
    }
    public Vector3 Localize(Vector3 to, Transform localize)
    {
        float x = to.x;
        float y = to.y;
        float z = to.z;

        return localize.right * x + localize.up * y + localize.forward * z;
    }
    public void Move(Transform transform, ref float overrideSpeed, ref float overrideSlowMod, ref float overrideFastMod, float manuvarabilty)
    {
        float mouseX = Input.GetAxis("Mouse X") * (invertX ? -1f : 1f);
        float mouseY = -Input.GetAxis("Mouse Y") * (invertY ? -1f : 1f);


        transform.RotateAround(transform.position, GetAxis(this.mouseX, transform), (mouseSensitivity * manuvarabilty) * mouseX * Time.deltaTime);
        transform.RotateAround(transform.position, GetAxis(this.mouseY, transform), (mouseSensitivity * manuvarabilty) * mouseY * Time.deltaTime);

        player.SetCamera(mouseX, mouseY);
        if (doOverrideSpeed)
        {
            overrideSpeed = this.overrideSpeed;
        }
        if (doOverrideSlowMod)
        {
            overrideSlowMod = this.overrideSlowMod;
        }
        if (doOverrideFastMod)
        {
            overrideFastMod = this.overrideFastMod;
        }
    }
    public Vector3 GetAxis(Axis axis, Transform transform)
    {
        if (axis == Axis.X)
        {
            return transform.right;
        }
        else if (axis == Axis.Y)
        {
            return transform.up;
        }
        else if (axis == Axis.Z)
        {
            return transform.forward;
        }
        return transform.forward;
    }
}
