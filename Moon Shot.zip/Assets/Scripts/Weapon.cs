﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Save1401;

public enum FireMethod { MouseDown, MouseUp, MouseConstant, Passive }
public class Weapon : MonoBehaviour
{
    public GameObject projectile;
    public Transform firePoint;
    public float fireForce;
    public bool canFire;
    public FireMethod fm;
    public bool delayFire;
    [ConditionalProperty("delayFire")]
    public float fireRate;
    float timeTillNextShot = 0f;
    public bool loaded;
    // Start is called before the first frame update
    void Start()
    {
        timeTillNextShot = fireRate;
    }

    // Update is called once per frame
    void Update()
    {
        loaded = Timer.Countdown(ref timeTillNextShot);
        if (canFire)
        {
            if (fm == FireMethod.MouseDown)
            {
                if (Input.GetMouseButtonDown(0))
                    Fire();
            }
            else if (fm == FireMethod.MouseUp)
            {
                if (Input.GetMouseButtonUp(0))
                    Fire();
            }
            else if (fm == FireMethod.MouseConstant)
            {
                if (Input.GetMouseButton(0))
                    Fire();
            }
        }
    }
    public void Fire()
    {
        if (!delayFire)
        {
            Instantiate(projectile, firePoint.position, firePoint.rotation).GetComponent<Rigidbody>().AddForce(firePoint.forward * fireForce);
        }
        else if (loaded)
        {
            Instantiate(projectile, firePoint.position, firePoint.rotation).GetComponent<Rigidbody>().AddForce(firePoint.forward * fireForce);
            timeTillNextShot = fireRate;
        }
    }
}
