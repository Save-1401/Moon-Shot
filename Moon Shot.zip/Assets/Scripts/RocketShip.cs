﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum Axis { X, Y, Z }
public class RocketShip : MonoBehaviour
{
    public Stats stats;
    public SFX sfx;
    public bool isDead;
    public Rigidbody rb;
    public Transform cam;
    public float rotClamp;
    public float maxRange;
    [HideInInspector]
    public CameraSetting currentCameraSetting;
    public bool canChangeSetting;
    public CameraSetting takeOff;
    public GameObject takeOffParticles;
    public GameObject normalParticles;
    public CameraSetting firstPerson;
    public CameraSetting thirdPerson;
    public CameraSetting destroyed;
    /*public CameraSetting landing;
    CameraSetting previous;
    public bool isLanding;
    public float landRange;*/
    [Range(0f, 1f)]
    public float slowDown;
    [Range(0f, 1f)]
    public float velocityDown;
    public bool setCamAsChildOfPart = true;
    [ConditionalProperty("setCamAsChildOfPart")]
    public int part;
    public GameObject[] brokenParts;

    public List<Weapon> currentWeapons;

    [System.Serializable]
    public class Stats
    {
        public int points;
        public enum UpgradeType { HullIntegrity, Speed, Inertia, SlowMod, FastMod, Manuverabilty }
        public UpgradeType[] ut = new UpgradeType[] { UpgradeType.HullIntegrity, UpgradeType.Speed,
            UpgradeType.Inertia, UpgradeType.SlowMod, UpgradeType.FastMod, UpgradeType.Manuverabilty };
        public float hullIntegrity = 100f;
        public float speed = 2500f;
        public float inertia = 0.9f;
        public float slowMod = 0.1f;
        public float fastMod = 2.5f;
        public float manuverability = 1f;

        public Levels levels;
        public Upgrades upgrades;
        public PointsToUpgrade pointsToUpgrade;

        [System.Serializable]
        public class Levels
        {
            public int hullIntegrity = 0;
            public int speed = 0;
            public int inertia = 0;
            public int slowMod = 0;
            public int fastMod = 0;
            public int manuverability = 0;
        }
        [System.Serializable]
        public class Upgrades
        {
            public float[] hullIntegrity;
            public float[] speed;
            public float[] inertia;
            public float[] slowMod;
            public float[] fastMod;
            public float[] manuverability;
        }
        [System.Serializable]
        public class PointsToUpgrade
        {
            public int[] hullIntegrity;
            public int[] speed;
            public int[] inertia;
            public int[] slowMod;
            public int[] fastMod;
            public int[] manuverability;
        }

        public void Upgrade(UpgradeType ut)
        {
            if (ut == UpgradeType.HullIntegrity)
            {
                if (levels.hullIntegrity < upgrades.hullIntegrity.Length - 1)
                {
                    if (points >= pointsToUpgrade.hullIntegrity[levels.hullIntegrity])
                    {
                        points -= pointsToUpgrade.hullIntegrity[levels.hullIntegrity];
                        levels.hullIntegrity++;
                        hullIntegrity = upgrades.hullIntegrity[levels.hullIntegrity];
                    }
                }
            }
            else if (ut == UpgradeType.Speed)
            {
                if (levels.speed < upgrades.speed.Length - 1)
                {
                    if (points >= pointsToUpgrade.speed[levels.speed])
                    {
                        points -= pointsToUpgrade.speed[levels.speed];
                        levels.speed++;
                        speed = upgrades.speed[levels.speed];
                    }
                }
            }
            else if (ut == UpgradeType.Inertia)
            {
                if (levels.inertia < upgrades.inertia.Length - 1)
                {
                    if (points >= pointsToUpgrade.inertia[levels.inertia])
                    {
                        points -= pointsToUpgrade.inertia[levels.inertia];
                        levels.inertia++;
                        inertia = upgrades.inertia[levels.inertia];
                    }
                }
            }
            else if (ut == UpgradeType.SlowMod)
            {
                if (levels.slowMod < upgrades.slowMod.Length - 1)
                {
                    if (points >= pointsToUpgrade.slowMod[levels.slowMod])
                    {
                        points -= pointsToUpgrade.slowMod[levels.slowMod];
                        levels.slowMod++;
                        slowMod = upgrades.slowMod[levels.slowMod];
                    }
                }
            }
            else if (ut == UpgradeType.FastMod)
            {
                if (levels.fastMod < upgrades.fastMod.Length - 1)
                {
                    if (points >= pointsToUpgrade.fastMod[levels.fastMod])
                    {
                        points -= pointsToUpgrade.fastMod[levels.fastMod];
                        levels.fastMod++;
                        fastMod = upgrades.fastMod[levels.fastMod];
                    }
                }
            }
            else if (ut == UpgradeType.Manuverabilty)
            {
                if (levels.manuverability < upgrades.manuverability.Length - 1)
                {
                    if (points >= pointsToUpgrade.manuverability[levels.manuverability])
                    {
                        points -= pointsToUpgrade.manuverability[levels.manuverability];
                        levels.manuverability++;
                        manuverability = upgrades.manuverability[levels.manuverability];
                    }
                }
            }
        }
    }
    [System.Serializable]
    public class SFX
    {
        public AudioSource hit;
        public AudioSource moonOre;

        public void Play(AudioSource toPLay)
        {
            toPLay.Play();
        }
    }
    public void Upgrade(int ut)
    {
        for (int i = 0; i < stats.ut.Length; i++)
        {
            if (i == ut)
            {
                stats.Upgrade(stats.ut[i]);
            }
        }
    }

    float delay = 1f;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        takeOff.Start(this);
        firstPerson.Start(this);
        thirdPerson.Start(this);
        destroyed.Start(this);
        //landing.Start(this);
        currentCameraSetting = firstPerson;
    }

    // Update is called once per frame
    void Update()
    {
        CheckCam();
        /*if (isLanding)
            Land(previous);*/
        Move();
        if (canChangeSetting)
            CheckPOV();
        CheckHull();
        ClampRot();
        MonitorDistance();
    }
    public void CheckCam()
    {
        if (currentCameraSetting.name == takeOff.name/* || currentCameraSetting.name == landing.name*/)
        {
            takeOffParticles.SetActive(true);
            normalParticles.SetActive(false);
        }
        else
        {
            takeOffParticles.SetActive(false);
            normalParticles.SetActive(true);
        }
        /*if (currentCameraSetting.name == landing.name)
        {
            isLanding = true;
        }
        else
        {
            isLanding = false;
        }*/
    }
    public void SetCamera(float xLag, float yLag)
    {
        currentCameraSetting.SetCamera(transform, cam, xLag, yLag);
    }
    /*public void Land(CameraSetting prevCamSet)
    {
        Ray ray = new Ray(transform.position, -transform.forward);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, landRange))
        {
            if (hit.transform == null)
            {
                currentCameraSetting = prevCamSet;
                transform.parent = null;
            }
            else
            {
                transform.parent = hit.transform;
            }
        }
        else
        {
            currentCameraSetting = prevCamSet;
            transform.parent = null;
        }
    }*/
    public void Move()
    {
        if (delay <= 0)
        {
            float overideSpeed = stats.speed;
            float overrideSlowMod = stats.slowMod;
            float overrideFastMod = stats.fastMod;
            currentCameraSetting.Move(transform, ref overideSpeed, ref overrideSlowMod, ref overrideFastMod, stats.manuverability);

            Vector3 desiredVelocity = transform.forward * overideSpeed * (Input.GetAxisRaw("Vertical") >= 0 ? (Input.GetAxisRaw("Vertical") > 0 ? overrideFastMod : 1) : overrideSlowMod) * Time.deltaTime;
            rb.velocity = Vector3.Lerp(rb.velocity, desiredVelocity, stats.inertia * Time.deltaTime);
            rb.angularVelocity = Vector3.zero;
        }
        else
        {
            delay -= Time.deltaTime;
        }

        if (Input.GetAxisRaw("Vertical") > 0)
        {
            foreach (Weapon w in currentWeapons)
            {
                w.canFire = false;
            }
        }
        else
        {
            foreach (Weapon w in currentWeapons)
            {
                w.canFire = true;
            }
        }
    }
    public void ClampRot()
    {
        transform.rotation = Quaternion.Euler(FloatToAngle(Mathf.Clamp(FloatToAngle(transform.eulerAngles.x + 180), -rotClamp + 180, rotClamp + 180) - 180),
            FloatToAngle(Mathf.Clamp(FloatToAngle(transform.eulerAngles.y + 180), -rotClamp + 180, rotClamp + 180) - 180),
            transform.eulerAngles.z);
    }
    public float FloatToAngle(float toAngle)
    {
        for (int i = 0; toAngle >= 360; i++)
        {
            toAngle -= 360;
        }
        for (int i = 0; toAngle < 0; i++)
        {
            toAngle += 360;
        }
        return toAngle;
    }
    public void MonitorDistance()
    {
        if (Vector2.Distance(transform.position, Vector2.zero) > maxRange)
        {
            Vector3 normRelPos = ((Vector2)transform.position).normalized;
            Vector3 pos = normRelPos * -maxRange;
            transform.position = pos + Vector3.forward * transform.position.z;
        }
    }
    public void CheckPOV()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            //previous = currentCameraSetting;
            currentCameraSetting = firstPerson;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            //previous = currentCameraSetting;
            currentCameraSetting = thirdPerson;
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            //previous = currentCameraSetting;
            //currentCameraSetting = landing;
        }
    }
    public void CheckHull()
    {
        if (stats.hullIntegrity <= 0)
        {
            Crash();
        }
    }
    public void Crash()
    {
        currentCameraSetting = destroyed;
        SetCamera(0f, 0f);
        cam.parent = null;
        for (int i = 0; i < brokenParts.Length; i++)
        {
            GameObject piece = Instantiate(brokenParts[i], transform);
            piece.GetComponent<Rigidbody>().velocity = rb.velocity * velocityDown;
            piece.transform.parent = null;
            if (setCamAsChildOfPart && i == part)
            {
                cam.transform.parent = piece.transform;
            }
        }
        Time.timeScale = slowDown;
        Cursor.lockState = CursorLockMode.None;
        isDead = true;
        gameObject.SetActive(false);
        //Destroy(gameObject);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag != "Lunar Ore" && collision.collider.GetComponent<Rigidbody>() != null)
        {
            Rigidbody otherRb = collision.collider.GetComponent<Rigidbody>();

            stats.hullIntegrity -= (Mathf.Abs(rb.velocity.x) + Mathf.Abs(rb.velocity.y) + Mathf.Abs(otherRb.velocity.x) + Mathf.Abs(otherRb.velocity.y));

            sfx.Play(sfx.hit);
        }
        else if (collision.collider.tag == "Lunar Ore" && collision.collider.GetComponent<LunarOre>() != null)
        {
            stats.points += collision.collider.GetComponent<LunarOre>().points;
            collision.collider.GetComponent<LunarOre>().OnPlayerHit();

            sfx.Play(sfx.moonOre);
        }
    }
}
