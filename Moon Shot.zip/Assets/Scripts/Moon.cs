﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moon : MonoBehaviour
{
    public Transform planet;
    public Vector3 axis;
    public Vector2 positionRange;
    public bool doRandomSpeed;
    [ConditionalProperty("doRandomSpeed")]
    public Vector2 speedRange;
    public float speed;
    public bool doRandomScale;
    [ConditionalProperty("doRandomScale")]
    public Vector2 scaleRange;
    // Start is called before the first frame update
    void Start()
    {
        axis = GenerateAxis();
        transform.position = new Vector3(axis.y, axis.z, axis.x) * Random.Range(positionRange.x, positionRange.y);
        if (doRandomSpeed)
        {
            speed = Random.Range(speedRange.x, speedRange.y);
        }
        if (doRandomScale)
        {
            transform.localScale = Vector3.one * Random.Range(scaleRange.x, scaleRange.y);
        }
    }

    // Update is called once per frame
    void Update()
    {
        transform.RotateAround(planet.position, axis, speed * Time.deltaTime);
    }
    public Vector3 GenerateAxis()
    {
        return new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;
    }
}
