﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public bool doVelocity;
    [ConditionalProperty("doVelocity")]
    public Rigidbody rb;
    public bool doHealth;
    [ConditionalProperty("doHealth")]
    public float health;
    //public MeshRenderer mr;
    public AsteroidSpawner aS;
    public Transform center;
    public Transform player;
    public bool canSetMaxRange;
    [ConditionalProperty("canSetMaxRange")]
    public float maxRange;
    public float maxPlayerRange;
    public Vector3 relativePosition;
    public void Set(AsteroidSpawner aS)
    {
        this.aS = aS;
        if (doVelocity)
            rb.velocity = aS.CalculateRandomVelocity();
        center = aS.transform;
        if (!canSetMaxRange)
            maxRange = aS.asteroidSpawnRadiusRange.y;
        maxPlayerRange = aS.maxPlayerDistance;
        player = aS.player;
        if (doHealth)
            health = aS.GenerateRandomHealth();
    }
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (center != null)
            relativePosition = transform.position - center.position;
        //MonitorAsteroidDistance();
        //MonitorPlayerDistance();
        if (doHealth)
            CheckHealth();
    }
    public void MonitorAsteroidDistance()
    {
        if (Vector3.Distance(transform.position, center.position) > maxRange)
        {
            Vector3 normRelPos = relativePosition.normalized;
            Vector3 pos = -normRelPos * maxRange;
            transform.position = pos;
        }
    }
    public void MonitorPlayerDistance()
    {
        if (Vector3.Distance(transform.position, player.position) <= maxPlayerRange)
        {
        }
        else// if (Vector3.Distance(transform.position, player.position) > maxPlayerRange)
        {
            aS.asteroidsDeactivated.Add(gameObject);
            gameObject.SetActive(false);
        }
    }
    public void CheckHealth()
    {
        if (health <= 0)
        {
            if (aS.asteroidsDeactivated.Contains(gameObject))
                aS.asteroidsDeactivated.Remove(gameObject);
            Destroy(gameObject);
            return;
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (doHealth)
        {
            if (collision.collider.gameObject.GetComponent<Projectile>() != null)
            {
                Projectile p = collision.collider.gameObject.GetComponent<Projectile>();
                health -= p.damage;
                if (p.destryOnHit)
                    Destroy(collision.collider.gameObject);
            }
        }
    }
}
