﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Save1401
{
    [ExecuteInEditMode]
    public class Bounds : MonoBehaviour
    {
        public Vector2 xBounds;
        public Vector2 yBounds;
        private void Update()
        {
            DrawBorders();
        }
        public void DrawBorders()
        {
            Debug.DrawLine(new Vector3(transform.position.x + xBounds.x, transform.position.y + yBounds.x), new Vector3(transform.position.x + xBounds.x, transform.position.y + yBounds.y), Color.blue);
            Debug.DrawLine(new Vector3(transform.position.x + xBounds.y, transform.position.y + yBounds.x), new Vector3(transform.position.x + xBounds.y, transform.position.y + yBounds.y), Color.blue);
            Debug.DrawLine(new Vector3(transform.position.x + xBounds.x, transform.position.y + yBounds.x), new Vector3(transform.position.x + xBounds.y, transform.position.y + yBounds.x), Color.blue);
            Debug.DrawLine(new Vector3(transform.position.x + xBounds.x, transform.position.y + yBounds.y), new Vector3(transform.position.x + xBounds.y, transform.position.y + yBounds.y), Color.blue);
        }
        public bool isInBounds(Vector3 postion)
        {
            return isInXBounds(postion) && isInYBouds(postion);
        }
        public bool isInLadder(Vector2 postion)
        {
            return isInXBounds(postion) && isInYBouds(postion);
        }
        public bool isInXBounds(Vector3 position)
        {
            return position.x >= transform.position.x + xBounds.x && position.x <= transform.position.x + xBounds.y;
        }
        public bool isInXBounds(Vector2 position)
        {
            return position.x >= transform.position.x + xBounds.x && position.x <= transform.position.x + xBounds.y;
        }
        public bool isInYBouds(Vector3 position)
        {
            return position.y >= transform.position.y + yBounds.x && position.y <= transform.position.y + yBounds.y;
        }
        public bool isInYBouds(Vector2 position)
        {
            return position.y >= transform.position.y + yBounds.x && position.y <= transform.position.y + yBounds.y;
        }
        public int isOnXEdge(Vector3 position)
        {
            if (position.x == transform.position.x + xBounds.x)
            {
                return -1;
            }
            else if (position.x == transform.position.x + xBounds.y)
            {
                return 1;
            }
            return 0;
        }
        public int isOnYEdge(Vector3 position)
        {
            if (position.y == transform.position.y + yBounds.x)
            {
                return -1;
            }
            else if (position.y == transform.position.y + yBounds.y)
            {
                return 1;
            }
            return 0;
        }
    }
}
