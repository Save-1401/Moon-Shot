﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Save1401
{
    public static class General
    { 
        public static Transform GetClosest(List<Transform> inList, Vector3 currentPosition)
        {
            if (inList.Count == 0)
            {
                return null;
            }
            Transform closest = inList[0];
            for (int i = 0; i < inList.Count; i++)
            {
                if (Vector3.Distance(inList[i].position, currentPosition) < Vector3.Distance(closest.position, currentPosition))
                {
                    closest = inList[i];
                }
            }
            return closest;
        }
    }
    public static class Maths
    {
        public static int Spiral(int i, int spiralDirection)
        {
            int absI = Mathf.Abs(i);
            return ((absI * 2) + ((i == 0 ? -spiralDirection : i / absI) == spiralDirection ? 0 : 1)) * (i == 0 ? spiralDirection : -(i / absI));
        }
        public static void Iterate(ref int i, int max)
        {
            i++;
            if (i == max)
            {
                i = 0;
            }
        }
        public static void BackIterate(ref int i, int max)
        {
            i--;
            if (i < 0)
            {
                i = max - 1;
            }
        }
        public static Vector2 AngleToVector2(float angle, Transform dirs)
        {
            int sector = FindSectorAngle(angle);
            float percent = (angle - (sector * 90f)) / 90f;
            return FindDir(sector, percent, dirs);
        }
        public static int FindSectorAngle(float angle)
        {
            int sector = 0;

            if (angle >= 0 && angle < 90)
            {
                sector = 0;
            }
            else if (angle >= 90 && angle < 180)
            {
                sector = 1;
            }
            else if (angle >= 180 && angle < 270)
            {
                sector = 2;
            }
            else if (angle >= 270 && angle < 360)
            {
                sector = 3;
            }

            return sector;
        }
        public static Vector2 FindDir(int sector, float percent, Transform dirs)
        {
            Vector2 dirOne = GetDirOne(sector, dirs);
            Vector2 dirTwo = GetDirTwo(sector, dirs);

            return Vector2.Lerp(dirOne, dirTwo, percent).normalized;
        }
        public static Vector2 GetDirOne(int Sector, Transform dirs)
        {
            Vector2 dirOne = dirs.right;
            if (Sector == 0)
            {
                dirOne = dirs.right;
            }
            else if (Sector == 1)
            {
                dirOne = -dirs.up;
            }
            else if (Sector == 2)
            {
                dirOne = -dirs.right;
            }
            else if (Sector == 3)
            {
                dirOne = dirs.up;
            }
            return dirOne;
        }
        public static Vector2 GetDirTwo(int Sector, Transform dirs)
        {
            Vector2 dirTwo = dirs.forward;
            if (Sector == 0)
            {
                dirTwo = -dirs.up;
            }
            else if (Sector == 1)
            {
                dirTwo = -dirs.right;
            }
            else if (Sector == 2)
            {
                dirTwo = dirs.up;
            }
            else if (Sector == 3)
            {
                dirTwo = dirs.right;
            }
            return dirTwo;
        }
        public static float Vector2ToAngle(Vector2 vector, Transform dirs)
        {
            int sector = FindSectorVector2(vector);

            Vector2 dirOne = GetDirOne(sector, dirs);
            Vector2 dirTwo = GetDirTwo(sector, dirs);

            return (InverseLerp(dirOne, dirTwo , vector) * 90f) + (sector * 90f);
        }
        public static int FindSectorVector2(Vector2 vector)
        {
            int sector = 0;

            if (vector.x > 0 && vector.y < 0)
            {
                sector = 0;
            }
            else if (vector.x < 0 && vector.y < 0)
            {
                sector = 1;
            }
            else if (vector.x < 0 && vector.y > 0)
            {
                sector = 2;
            }
            else if (vector.x > 0 && vector.y > 0)
            {
                sector = 3;
            }

            return sector;
        }
        public static float InverseLerp(Vector3 a, Vector3 b, Vector3 value)
        {
            Vector3 AB = b - a;
            Vector3 AV = value - a;
            return Vector3.Dot(AV, AB) / Vector3.Dot(AB, AB);
        }
    }
    public static class Timer
    {
        public static bool Countdown(ref float time)
        {
            if (time <= 0)
            {
                return true;
            }
            else
            {
                time -= Time.deltaTime;
            }
            return false;
        }
        public static bool Countdown(ref float time, float maxTime, bool restart)
        {
            if (time <= 0)
            {
                if (restart)
                    time = maxTime;
                return true;
            }
            else
            {
                time -= Time.deltaTime;
            }
            return false;
        }
    }
    public static class Pathfinding
    {
        public static Vector3 GetDirection(Vector3 desiredLocation, Transform transform, string pathTag)
        {
            bool[] forwardValues = new bool[9];
            AngleRay[] angleRays = new AngleRay[9];
            for (int i = 0; i < forwardValues.Length; i++)
            {
                GetBool(i, forwardValues.Length, pathTag, transform, ref angleRays);
                bool b = FireRay(new Vector2(angleRays[i].r.y, angleRays[i].f.y), pathTag, transform);
                forwardValues[i] = b;
            }
            Vector2 desiredDirection = new Vector2((desiredLocation - transform.position).normalized.x, (desiredLocation - transform.position).normalized.z);
            AngleRay dir = null;
            int currentDir = 0;
            for (int i = 0; i < angleRays.Length; i++)
            {
                if (angleRays[i].Contains(desiredDirection))
                {
                    currentDir = 1;
                    dir = angleRays[i];
                }
            }
            if (dir == null)
            {
                if (desiredDirection.x < -0.25)
                {
                    dir = angleRays[0];
                }
                else if (desiredDirection.x > 0.25)
                {
                    currentDir = angleRays.Length - 1;
                    dir = angleRays[angleRays.Length - 1];
                }
                else
                {
                    currentDir = 4;
                    dir = angleRays[4];
                }
            }
            for (int i = 0; i < 5; i += Maths.Spiral(i, 1))
            {
                Debug.Log(i + "");
            }
            return new Vector3(desiredDirection.x, transform.position.y, desiredDirection.y);
        }
        public static void GetBool(int i, int length, string pathTag, Transform transform, ref AngleRay[] angleRays)
        {
            if (i == 0)
            {
                angleRays[i] = new AngleRay(new Vector2(-1, 0), 0.125f);
            }
            else if (i == length - 1)
            {
                angleRays[i] = new AngleRay(new Vector2(1, 0), 0.125f);
            }
            else if (i == 1)
            {
                angleRays[i] = new AngleRay(new Vector2(-1f / 3f, 2f / 3f), 0.125f);
            }
            else if (i == length - 2)
            {
                angleRays[i] = new AngleRay(new Vector2(1f / 3f, 2f / 3f), 0.125f);
            }
            else if (i == 2)
            {
                angleRays[i] = new AngleRay(new Vector2(-0.5f, 0.5f), 0.125f);
            }
            else if (i == length - 3)
            {
                angleRays[i] = new AngleRay(new Vector2(0.5f, 0.5f), 0.125f);
            }
            else if (i == 3)
            {
                angleRays[i] = new AngleRay(new Vector2(-2f / 3f, 1f / 3f), 0.125f);
            }
            else if (i == length - 4)
            {
                angleRays[i] = new AngleRay(new Vector2(2f / 3f, 1f / 3f), 0.125f);
            }
            else
            {
                angleRays[i] = new AngleRay(new Vector2(0, 1), 0.125f);
            }
        }
        public static bool FireRay(Vector2 dir, string pathTag, Transform transform)
        {
            Ray ray = new Ray(transform.position, transform.right * dir.x + transform.forward * dir.y - transform.up * 0.5f);
            Debug.DrawRay(transform.position, transform.right * dir.x + transform.forward * dir.y - transform.up * 0.5f);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform.tag == pathTag)
                {
                    return true;
                }
            }
            return false;
        }
        public class AngleRay
        {
            public Vector3 r;
            public Vector3 f;
            public Vector2 forward;
            public bool canSee;
            public AngleRay(Vector2 dir, float range)
            {
                r = new Vector3(dir.x - range, dir.x, dir.x + range);
                f = new Vector3(dir.y - range, dir.y, dir.y + range);
                this.forward = Vector2.up * f.y + Vector2.right * r.y;
            }
            public bool Contains(Vector2 contains)
            {
                float rr = Mathf.Round(contains.x * 100) / 100;
                float rf = Mathf.Round(contains.y * 100) / 100;
                return r.x < rr && rr < r.z && f.x < rf && rf < f.z;
            }
        }
    }
}
